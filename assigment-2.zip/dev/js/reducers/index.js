import {combineReducers} from 'redux';
import ActiveCartItems from './reducer-cart-item';
import ShowAlertReduce from './reducer-alert';
import DefaultProduct from './reducer-products';




/*
 * We combine all reducers into a single object before updated data is dispatched (sent) to store
 * Your entire applications state (store) is just whatever gets returned from all your reducers
 * */

const allReducers = combineReducers({
    activeCartItems: ActiveCartItems,
    alertData: ShowAlertReduce,
    defaultProduct: DefaultProduct
});

export default allReducers
