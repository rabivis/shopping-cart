import axios from 'axios';
const BASE_URL = 'http://localhost:3031/contacts/';
var products = require('json!../../../product-data.json');
/**
 * Action for set default product to reducer.
 */
export const getProductList = () => {
  return (dispatch) => {
      dispatch({type: 'DEFAULT_PRODUCT_LIST',payload: products});
    }
}
/**
 * Add product to activeCartItems.
 */
export const addToCart = (defaultProduct,activeCartItems,product) => {
    if(activeCartItems == null){
        activeCartItems = [];
    }
    const newCartItems = [...activeCartItems,product];
    return (dispatch) => {
      dispatch({type: 'ACTIVE_CART_ITEMS',payload: newCartItems});
    }
};
/**
 * Remove product to activeCartItems.
 */
export const removeToCart = (defaultProduct,activeCartItems,product) => {
    const filteredItems = activeCartItems.filter(item => item !== product)
    return (dispatch) => {
      dispatch({type: 'ACTIVE_CART_ITEMS',payload: filteredItems});
    }
}

export const showAlert = (data) => {
  return (dispatch) => {
      dispatch({type: 'SHOW_ALERT_MESSAGE',payload: data});
      setTimeout(
          function() {
              const data = [...data,{show:false}];              
          }
          .bind(dispatch),
          5000
      );
    }
};




