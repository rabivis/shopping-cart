import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {addToCart} from '../actions/index';
import { Button } from 'react-bootstrap';


class AddToCartButton extends Component {

  constructor(props) {
    super(props)
    this.addToCart = this.addToCart.bind(this);
  }
  addToCart(){
      const {product,activeCartItems,defaultProduct} = this.props;
      this.props.addToCart(defaultProduct,activeCartItems,product);
  }
  render() {
      return (<Button onClick={() => this.addToCart()} bsClass="btn btn-default">Add to Cart</Button>);
  }
}

// Get apps state and pass it as props to UserList
function mapStateToProps(state) {
    return {
        defaultProduct: state.defaultProduct,
        activeCartItems: state.activeCartItems
    };
}


// Get actions and pass them as props to to UserList
function matchDispatchToProps(dispatch){
  return bindActionCreators({addToCart}, dispatch);
}

// We don't want to return the plain UserList (component) anymore, we want to return the smart Container
//      > UserList is now aware of state and actions
export default connect(mapStateToProps, matchDispatchToProps)(AddToCartButton);
